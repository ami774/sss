# Images
Store all images for your elFinder skin in this directory.

It is best to group similar images into one file and use the files as CSS spritesheets.
